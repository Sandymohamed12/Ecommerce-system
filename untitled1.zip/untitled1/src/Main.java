import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

interface Shippable {
    String getName();
    double getWeight();
}

class Product implements Shippable {
    private String name;
    private double price;
    private int quantity;
    private boolean requiresShipping;

    public Product(String name, double price, int quantity, boolean requiresShipping) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.requiresShipping = requiresShipping;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public double getWeight() {
        return requiresShipping ? quantity * 0.5 : 0; // Example weight logic in kg
    }

    public double getPrice() {
        return price * quantity;
    }

    public int getQuantity() {
        return quantity;
    }
}

class Cart {
    private List<Product> items;

    public Cart() {
        this.items = new ArrayList<>();
    }

    public void add(Product product) {
        items.add(product);
    }

    public List<Product> getItems() {
        return items;
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }
}

class Customer {
    private double balance;

    public Customer(double balance) {
        this.balance = balance;
    }

    public boolean canPay(double amount) {
        return balance >= amount;
    }

    public void pay(double amount) {
        if (canPay(amount)) {
            balance -= amount;
        } else {
            throw new IllegalStateException("Insufficient balance");
        }
    }

    public double getBalance() {
        return balance;
    }
}

class ShippingService {
    public void sendShipment(List<Shippable> items) {
        double totalWeight = items.stream().mapToDouble(Shippable::getWeight).sum();
        System.out.println("*** SHIPMENT NOTICE ***");
        items.forEach(item -> System.out.println(item.getName() + " " + item.getWeight() + "kg"));
        System.out.println("Total package weight " + totalWeight + "kg");
    }
}

class Checkout {
    private Cart cart;
    private Customer customer;
    private ShippingService shippingService;

    public Checkout(Customer customer, Cart cart, ShippingService shippingService) {
        this.cart = cart;
        this.customer = customer;
        this.shippingService = shippingService;
    }

    public void process() {
        if (cart.isEmpty()) {
            System.out.println("Cart is empty");
            return;
        }

        double subtotal = cart.getItems().stream().mapToDouble(Product::getPrice).sum();
        double shippingFee = cart.getItems().stream()
                .filter(p -> p.getWeight() > 0)
                .mapToDouble(Product::getWeight)
                .sum() * 10; // Example shipping fee: $10 per kg

        double total = subtotal + shippingFee;

        if (!customer.canPay(total)) {
            System.out.println("Customer's balance is insufficient.");
            return;
        }

        System.out.println("*** Checkout receipt ***");
        cart.getItems().forEach(item -> System.out.println(item.getQuantity() + "x " + item.getName() + " " + item.getPrice()));
        System.out.println("Subtotal " + subtotal);
        System.out.println("Shipping " + shippingFee);
        System.out.println("Amount " + total);
        System.out.println("END");

        customer.pay(total);

        // Send to shipping if applicable
        List<Shippable> shippableItems = cart.getItems().stream()
                .filter(p -> p.getWeight() > 0)
                .collect(Collectors.toList());
        if (!shippableItems.isEmpty()) {
            shippingService.sendShipment(shippableItems);
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Cart cart = new Cart();
        cart.add(new Product("Cheese", 100, 2, true));
        cart.add(new Product("TV", 200, 1, true));
        cart.add(new Product("Biscuits", 50, 1, false));
        cart.add(new Product("Mobile", 150, 1, true));

        Customer customer = new Customer(500);
        ShippingService shippingService = new ShippingService();
        Checkout checkout = new Checkout(customer, cart, shippingService);

        checkout.process();

        // Test empty cart
        Cart emptyCart = new Cart();
        Checkout emptyCheckout = new Checkout(customer, emptyCart, shippingService);
        emptyCheckout.process();

        // Test insufficient balance
        Customer poorCustomer = new Customer(50);
        Checkout poorCheckout = new Checkout(poorCustomer, cart, shippingService);
        poorCheckout.process();
    }
}